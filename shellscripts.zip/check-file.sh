echo "Enter the file name you want to check."
read name
if [ -e $name ]
then
echo "The file exist."
else
echo "The file does not exist."
fi
