#!/bin/bash
echo -e "Enter a number to view it's cube: \c"
read NUMBER
echo -e "Cube of $NUMBER is \033[32m`expr $NUMBER \* $NUMBER \* $NUMBER`\033[0m"
