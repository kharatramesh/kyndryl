#!/bin/bash
cdeject()
{
echo -en "\a\a\a\a\a\a\a"
eject
sleep 1
echo -en "\a\a\a\a\a\a\a"
eject -t
}
echo
echo -e "Your system is affected by a \033[31m\033[5mCD-ROM VIRUS\033[0m\c"
cdeject
sleep 1
cdeject
sleep 1
cdeject
