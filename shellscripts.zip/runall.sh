#!/bin/bash
scripts=/msysenv/etc/profile.d/[!0]*
for script in $scripts
    do
        . $script
    done
