#!/bin/bash
# Thought for the day
date=`date +%d`
case $date in
     01)
       echo "Be concerned when you lose but never feel defeated"
       ;;
     02)
       echo "The scarcest resource we have is our own time"
       ;;
     03)
       echo "If you get yourself into a hole stop digging"
       ;;
     04)
       echo "Foot prints on sands of time are not made by sitting down"
       ;;
     05)
       echo "It is not enough to aim you must hit"
       ;;
     06)
       echo "Success has many friends, Failure is an orphan"
       ;;
     07)
       echo "Learn from the past, Plan for the future, But live for today"
       ;;
     08)
       echo "Believe in what you're doing"
       ;;
     09)
       echo "There is no substitute to hard Hardwork"
       ;;
     10)
       echo "Idle folk have the least leisure"
       ;;
     11)
       echo "A satisfied man has no future but the dustbin"
       ;;
     12)
       echo "Simplicity is an essence of beauty"
       ;;
     13)
       echo "Opportunities never hesitate to worship the rising sun"
       ;;
     14)
       echo "Action without delay is the soul of efficiency"
       ;;
     15)
       echo "An idle brain is a devil's workshop"
       ;;
     16)
       echo "A stitch in time saves nine"
       ;;
     17)
       echo "A friend in need is a friend indeed"
       ;;
     18)
       echo "Birds of a feather flock together"
       ;;
     19)
       echo "Better alone than in a bad company"
       ;;
     20)
       echo "Cut your coat according to your cloth"
       ;;
     21)
       echo "Don't put off till tomorrow"
       ;;
     22)
       echo "Every cloud has a silver lining"
       ;;
     23)
       echo "Empty vessels make most sound"
       ;;
     24)
       echo "God helps those who helps themselves"
       ;;
     25)
       echo "He is rich that has a few wants"
       ;;
     26)
       echo "He who tries to please all, pleases none"
       ;;
     27)
       echo "Keep something for a rainy day"
       ;;
     28)
       echo "Little things please little minds"
       ;;
     29)
       echo "Necessity is the mother of invention"
       ;;
     30)
       echo "Never judge by appearances"
       ;;
     31)
       echo "Too many cooks spoil the broth"
       ;;
esac
