#!/bin/bash
mkdir -p /xzone/.backups/msysbkp
dd if=/dev/hda of=/xzone/.backups/msysbkp/mbr.bkp bs=1 count=512
dd if=/dev/fd0 of=/xzone/.backups/msysbkp/bootdisk.iso
fdisk -l > /xzone/.backups/msysbkp/fdisk
df -h > /xzone/.backups/msysbkp/df
cp -a /boot /xzone/.backups/msysbkp
cp -a /etc /xzone/.backups/msysbkp
mv /root/* /xzone/.backups/msysbkp
find / | grep -v -e ^/proc -e ^/backup -e ^/ezone -e ^/xzone > /xzone/.backups/msysbkp/find
