clear
df -h | grep $1 | awk '{print $3}'
sleep 0.5
. status.sh
